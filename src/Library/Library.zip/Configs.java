package Library;

public class Configs {
    protected static String dbHost = "localhost";
    protected static String dbPort = "3306";
    protected static String dbUser = "admin";
    protected static String dbPass = "adminU1810140";
    protected static String dbPath = "library_database";
}
